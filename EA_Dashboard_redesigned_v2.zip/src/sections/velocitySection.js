import { escapeHtml, formatNumber } from '../utils/format.js';

const METRICS = [
  { key: 'plannedSP', label: 'PLANNED (SP)', group: 'Sprint Delivery', unit: 'sp', direction: 'lower' },
  { key: 'completedSP', label: 'COMPLETED (SP)', group: 'Sprint Delivery', unit: 'sp', direction: 'higher' },
  { key: 'predictability', label: 'Sprint PREDICTABILITY (%)', group: 'Sprint Delivery', unit: '%', direction: 'higher', calculated: true },
  { key: 'carryOverSP', label: 'CARRY OVER (SP)', group: 'Sprint Delivery', unit: 'sp', direction: 'lower' },
  { key: 'carryOverPct', label: 'CARRY OVER (%)', group: 'Sprint Delivery', unit: '%', direction: 'lower', calculated: true },
  { key: 'workItemsCompleted', label: 'WORK ITEMS COMPLETED', group: 'Productivity', unit: 'count', direction: 'higher' },
  { key: 'scopeChange', label: 'SCOPE CHANGE (SP)', group: 'Productivity', unit: 'sp', direction: 'lower' },
  { key: 'bugsFixed', label: 'BUGS FIXED', group: 'Productivity', unit: 'count', direction: 'higher' },
  { key: 'bugRatio', label: 'BUG RATIO (%)', group: 'Productivity', unit: '%', direction: 'lower', calculated: true },
  { key: 'devCompletedSP', label: 'DEV COMPLETED (SP)', group: 'DEV Team', unit: 'sp', direction: 'higher' },
  { key: 'devAverage', label: 'AVG SP / DEVELOPER', group: 'DEV Team', unit: 'sp', direction: 'higher' },
  { key: 'qaCompletedSP', label: 'QA COMPLETED (SP)', group: 'QA Team', unit: 'sp', direction: 'higher' },
  { key: 'qaAverage', label: 'AVG SP / QA', group: 'QA Team', unit: 'sp', direction: 'higher' },
];
const DISTRIBUTION = [
  ['notStarted', 'Not Started'], ['inProgress', 'In Progress'], ['codeReview', 'Code Review'],
  ['readyForQA', 'Ready for QA'], ['inQA', 'In QA'], ['blocked', 'Blocked / On Hold'],
];

function num(value) { const n = Number(value); return Number.isFinite(n) ? n : 0; }
function calc(sprint, key) {
  const raw = (field) => sprint?.[field] === '' || sprint?.[field] === null || sprint?.[field] === undefined ? null : num(sprint[field]);
  if (key === 'predictability') {
    const completed = raw('completedSP'), planned = raw('plannedSP');
    return completed === null || planned === null || planned === 0 ? null : completed / planned * 100;
  }
  if (key === 'carryOverPct') {
    const carry = raw('carryOverSP'), planned = raw('plannedSP');
    return carry === null || planned === null || planned === 0 ? null : carry / planned * 100;
  }
  if (key === 'bugRatio') {
    const bugs = raw('bugsFixed'), items = raw('workItemsCompleted');
    return bugs === null || items === null || items === 0 ? null : bugs / items * 100;
  }
  return raw(key);
}
function valueLabel(value, metric) {
  if (value == null || !Number.isFinite(value)) return '—';
  if (metric.unit === '%') return `${value.toLocaleString('en-GB', { maximumFractionDigits: 1 })}%`;
  return value.toLocaleString('en-GB', { maximumFractionDigits: 1 });
}
function avg(values) {
  const valid = values.filter((v) => Number.isFinite(v));
  return valid.length ? valid.reduce((a, b) => a + b, 0) / valid.length : null;
}
function getOrdered(sprints) {
  return [...(Array.isArray(sprints) ? sprints : [])].sort((a, b) =>
    String(a.startDate || a.createdAt || '').localeCompare(String(b.startDate || b.createdAt || '')));
}
function currentAndCompleted(sprints) {
  const ordered = getOrdered(sprints);
  const current = [...ordered].reverse().find((s) => !s.completed) || null;
  const completed = ordered.filter((s) => s.completed && s.id !== current?.id).slice(-7);
  return { current, completed, ordered };
}
function safeText(value) { return escapeHtml(String(value ?? '')); }

export function renderVelocitySection(state) {
  const sprints = getOrdered(state.velocityReportSprints || []);
  const { current, completed } = currentAndCompleted(sprints);
  const last3 = completed.slice(-3);
  const history = completed.slice(-7);
  const reportSprints = last3;
  const allMetrics = METRICS;
  const currentMetrics = current || {};
  const totalPlanned = current ? calc(current, 'plannedSP') : 0;
  const totalCompleted = current ? calc(current, 'completedSP') : 0;
  const overallPredictability = current && totalPlanned ? totalCompleted / totalPlanned * 100 : 0;
  return `
    <section class="panel-stack velocity-workspace">
      <section class="velocity-hero">
        <div>
          <p class="section-kicker">Delivery intelligence</p>
          <h1>Velocity & Sprint Analysis</h1>
          <p>Track delivery, compare the last three completed sprints, and keep a seven-sprint performance history.</p>
        </div>
        <div class="velocity-hero__actions">
          <button class="button button--secondary" type="button" data-action="add-velocity-sprint">＋ Add sprint data</button>
          <button class="button button--primary" type="button" data-action="generate-confluence-report">Generate Confluence Report ↗</button>
        </div>
      </section>
      <section class="velocity-kpis">
        ${kpi('Current sprint', current?.label || 'No sprint added', current ? `${current.completed ? 'Completed' : 'In progress'}` : 'Add your first sprint')}
        ${kpi('Planned SP', current ? valueLabel(totalPlanned, {unit:'sp'}) : '—', 'Current sprint')}
        ${kpi('Completed SP', current ? valueLabel(totalCompleted, {unit:'sp'}) : '—', 'Current sprint')}
        ${kpi('Predictability', current ? valueLabel(overallPredictability, {unit:'%'}) : '—', 'Completed / planned')}
      </section>

      <section class="board-card velocity-section-card">
        <div class="section-header-inline">
          <div><p class="section-kicker">Confluence-ready comparison</p><h2>Last 3 completed sprints</h2><p class="velocity-subtitle">The reporting window excludes the current sprint while it is still in progress.</p></div>
          <span class="sprint-members-count">${reportSprints.length}/3 sprints</span>
        </div>
        ${renderComparisonTable(current, reportSprints)}
        <div class="velocity-chart-grid">
          ${renderBarChart('Delivery · Story Points', reportSprints, ['plannedSP','completedSP','carryOverSP'], ['Planned','Completed','Carry over'])}
          ${renderLineChart('Predictability trend', history, 'predictability', '%')}
        </div>
        <div class="velocity-report-output" data-report-output hidden>
          <div class="section-header-inline"><h3>Confluence report</h3><button class="button button--ghost" type="button" data-action="copy-confluence-report">Copy report</button></div>
          <textarea class="field-input velocity-report-text" data-confluence-text rows="12" readonly></textarea>
          <p class="velocity-subtitle">The report uses only the last three completed sprints.</p>
        </div>
      </section>

      <section class="board-card velocity-section-card">
        <div class="section-header-inline">
          <div><p class="section-kicker">Performance history</p><h2>Last 7 completed sprints</h2><p class="velocity-subtitle">Historical charts use completed sprints only. Current sprint values remain visible above.</p></div>
          <span class="sprint-members-count">${history.length}/7 sprints</span>
        </div>
        <div class="velocity-chart-grid">
          ${renderBarChart('Planned vs completed SP', history, ['plannedSP','completedSP'], ['Planned','Completed'])}
          ${renderLineChart('Carry-over (%)', history, 'carryOverPct', '%')}
          ${renderLineChart('Bug ratio (%)', history, 'bugRatio', '%')}
          ${renderBarChart('DEV vs QA completed SP', history, ['devCompletedSP','qaCompletedSP'], ['DEV','QA'])}
        </div>
        <div class="table-wrap velocity-history-table">
          <table class="data-table">
            <thead><tr><th>Sprint</th><th>Planned SP</th><th>Completed SP</th><th>Predictability</th><th>Carry over</th><th>Bug ratio</th><th>Status</th></tr></thead>
            <tbody>${history.length ? history.map(s => `<tr><td>${safeText(s.label)}</td><td>${valueLabel(calc(s,'plannedSP'),{unit:'sp'})}</td><td>${valueLabel(calc(s,'completedSP'),{unit:'sp'})}</td><td>${valueLabel(calc(s,'predictability'),{unit:'%'})}</td><td>${valueLabel(calc(s,'carryOverPct'),{unit:'%'})}</td><td>${valueLabel(calc(s,'bugRatio'),{unit:'%'})}</td><td><span class="status-pill status-pill--done">Completed</span></td></tr>`).join('') : '<tr><td colspan="7">Add completed sprint data to build your history.</td></tr>'}</tbody>
          </table>
        </div>
      </section>

      <section class="board-card velocity-section-card">
        <div class="section-header-inline"><div><p class="section-kicker">Metrics register</p><h2>Sprint metrics</h2><p class="velocity-subtitle">Enter values manually. Calculated metrics update automatically.</p></div></div>
        ${renderSprintEditor(sprints)}
      </section>
    </section>
  `;
}

function kpi(label, value, hint) {
  return `<article class="velocity-kpi"><span>${safeText(label)}</span><strong>${safeText(value)}</strong><small>${safeText(hint)}</small></article>`;
}
function renderComparisonTable(current, last3) {
  const columns = [...(current ? [{sprint:current, label:'Current Sprint'}] : []), ...last3.map(s => ({sprint:s,label:s.label}))];
  return `<div class="table-wrap velocity-comparison-table"><table class="data-table"><thead><tr><th>KPI</th>${columns.map(c=>`<th>${safeText(c.label)}</th>`).join('')}<th>AVG (last 3)</th><th>TREND</th></tr></thead><tbody>
    ${METRICS.map(metric=> {
      const values = last3.map(s=>calc(s,metric.key));
      const mean = avg(values);
      const currentValue = current ? calc(current,metric.key) : null;
      const trend = current && currentValue !== null && mean !== null && mean !== 0 ? ((currentValue - mean) / Math.abs(mean)) * 100 : null;
      const trendGood = trend === null ? '' : ((metric.direction === 'higher' ? trend >= 0 : trend <= 0) ? 'is-positive' : 'is-negative');
      return `<tr><th>${safeText(metric.label)}</th>${columns.map(c=>`<td>${valueLabel(calc(c.sprint,metric.key),metric)}</td>`).join('')}<td class="velocity-avg">${valueLabel(mean,metric)}</td><td class="velocity-trend ${trendGood}">${trend === null ? '—' : `${trend > 0 ? '+' : ''}${trend.toLocaleString('en-GB',{maximumFractionDigits:1})}%`}</td></tr>`;
    }).join('')}
    <tr class="velocity-group-row"><th colspan="${columns.length + 3}">Work Distribution</th></tr>
    ${DISTRIBUTION.map(([key,label])=>`<tr><th>${safeText(label)}</th>${columns.map(c=>`<td>${valueLabel(c.sprint.distribution?.[key] === '' || c.sprint.distribution?.[key] == null ? null : num(c.sprint.distribution[key]),{unit:'count'})}</td>`).join('')}<td>—</td><td>—</td></tr>`).join('')}
  </tbody></table></div>`;
}
function renderSprintEditor(sprints) {
  return `<div class="velocity-sprint-editor">
    ${sprints.length ? sprints.map(s=>`<article class="velocity-sprint-edit-card">
      <div class="velocity-sprint-edit-card__head"><div><strong>${safeText(s.label)}</strong><small>${safeText(s.startDate || 'No start date')} · ${s.completed ? 'Completed' : 'Current / in progress'}</small></div><div class="velocity-inline-actions"><label class="velocity-check"><input type="checkbox" data-action="toggle-velocity-sprint-completed" data-sprint-id="${safeText(s.id)}" ${s.completed ? 'checked' : ''}/> Completed</label><button class="button button--ghost-danger btn-xs" type="button" data-action="remove-velocity-sprint" data-sprint-id="${safeText(s.id)}">Delete</button></div></div>
      <div class="velocity-edit-grid">
        <label>Sprint name<input class="field-input" data-action="update-velocity-sprint" data-sprint-id="${safeText(s.id)}" data-field="label" value="${safeText(s.label)}"/></label>
        <label>Start date<input type="date" class="field-input" data-action="update-velocity-sprint" data-sprint-id="${safeText(s.id)}" data-field="startDate" value="${safeText(s.startDate || '')}"/></label>
        ${METRICS.filter(m=>!m.calculated).map(m=>`<label>${safeText(m.label)}<input type="number" min="0" step="0.1" class="field-input" data-action="update-velocity-metric" data-sprint-id="${safeText(s.id)}" data-field="${m.key}" value="${safeText(s[m.key] ?? '')}" placeholder="—"/></label>`).join('')}
        ${DISTRIBUTION.map(([key,label])=>`<label>${safeText(label)}<input type="number" min="0" step="1" class="field-input" data-action="update-velocity-distribution" data-sprint-id="${safeText(s.id)}" data-field="${key}" value="${safeText(s.distribution?.[key] ?? '')}" placeholder="—"/></label>`).join('')}
      </div>
    </article>`).join('') : '<div class="empty-card"><h3>No sprint metrics yet</h3><p>Add a sprint data record, then enter the metrics from your Excel report.</p></div>'}
  </div>`;
}
function renderBarChart(title, sprints, keys, labels) {
  if (!sprints.length) return `<div class="velocity-chart"><h3>${safeText(title)}</h3><div class="velocity-chart-empty">Complete sprint records to see this chart.</div></div>`;
  const values = sprints.flatMap(s=>keys.map(k=>calc(s,k) ?? 0));
  const max = Math.max(...values,1);
  const width=620, height=230, left=38, top=18, bottom=42, chartH=height-top-bottom;
  const groupW=(width-left-12)/sprints.length, barW=Math.min(18,groupW/(keys.length+1));
  const bars=sprints.map((s,i)=>keys.map((key,j)=>{
    const v=calc(s,key) ?? 0, h=v/max*chartH, x=left+i*groupW+(groupW-(barW*keys.length+4*(keys.length-1)))/2+j*(barW+4);
    return `<rect x="${x}" y="${top+chartH-h}" width="${barW}" height="${h}" rx="3" class="chart-bar chart-bar--${j}"><title>${safeText(s.label)} · ${safeText(labels[j])}: ${valueLabel(v,{unit:'sp'})}</title></rect>`;
  }).join('')+`<text x="${left+i*groupW+groupW/2}" y="${height-18}" text-anchor="middle" class="chart-label">${safeText(s.label)}</text>`).join('');
  const grid=[0,.25,.5,.75,1].map(n=>`<line x1="${left}" x2="${width-8}" y1="${top+chartH*(1-n)}" y2="${top+chartH*(1-n)}" class="chart-grid"/><text x="${left-8}" y="${top+chartH*(1-n)+4}" text-anchor="end" class="chart-axis">${Math.round(max*n)}</text>`).join('');
  return `<div class="velocity-chart"><h3>${safeText(title)}</h3><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${safeText(title)}">${grid}${bars}</svg><div class="chart-legend">${labels.map((l,i)=>`<span><i class="chart-dot chart-dot--${i}"></i>${safeText(l)}</span>`).join('')}</div></div>`;
}
function renderLineChart(title, sprints, key, unit) {
  if (!sprints.length) return `<div class="velocity-chart"><h3>${safeText(title)}</h3><div class="velocity-chart-empty">Complete sprint records to see this chart.</div></div>`;
  const vals=sprints.map(s=>calc(s,key) ?? 0), max=Math.max(...vals,1)*1.1, min=Math.min(0,...vals);
  const width=620,height=230,left=40,right=16,top=18,bottom=42,chartH=height-top-bottom,chartW=width-left-right;
  const points=vals.map((v,i)=>`${left+(sprints.length===1?chartW/2:i*chartW/(sprints.length-1))},${top+chartH-(v-min)/(max-min||1)*chartH}`).join(' ');
  const circles=vals.map((v,i)=>{const x=left+(sprints.length===1?chartW/2:i*chartW/(sprints.length-1)),y=top+chartH-(v-min)/(max-min||1)*chartH;return `<circle cx="${x}" cy="${y}" r="4" class="chart-point"><title>${safeText(sprints[i].label)}: ${valueLabel(v,{unit})}</title></circle><text x="${x}" y="${height-18}" text-anchor="middle" class="chart-label">${safeText(sprints[i].label)}</text>`}).join('');
  return `<div class="velocity-chart"><h3>${safeText(title)}</h3><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${safeText(title)}"><line x1="${left}" x2="${width-right}" y1="${top+chartH}" y2="${top+chartH}" class="chart-grid"/><polyline points="${points}" class="chart-line"/>${circles}</svg></div>`;
}
export function buildConfluenceReport(sprints) {
  const completed=getOrdered(sprints).filter(s=>s.completed).slice(-3);
  const lines=['Sprint Delivery & Velocity Report','',`Reporting window: ${completed.map(s=>s.label).join(', ') || 'No completed sprint data'}`,'','| KPI | '+completed.map(s=>s.label).join(' | ')+' | AVG |','|---|'+completed.map(()=> '---:').join('|')+'|---:|'];
  METRICS.forEach(m=>{const vals=completed.map(s=>calc(s,m.key));lines.push(`| ${m.label} | ${vals.map(v=>valueLabel(v,m)).join(' | ')} | ${valueLabel(avg(vals),m)} |`);});
  lines.push('','Work Distribution','', '| Sprint | '+DISTRIBUTION.map(d=>d[1]).join(' | ')+' |','|---|'+DISTRIBUTION.map(()=> '---:').join('|')+'|');
  completed.forEach(s=>lines.push(`| ${s.label} | ${DISTRIBUTION.map(([k])=>num(s.distribution?.[k])).join(' | ')} |`));
  return lines.join('\n');
}
